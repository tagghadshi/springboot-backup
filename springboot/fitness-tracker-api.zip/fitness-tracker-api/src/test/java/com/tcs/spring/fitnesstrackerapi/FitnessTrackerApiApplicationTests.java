package com.tcs.spring.fitnesstrackerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitnessTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
