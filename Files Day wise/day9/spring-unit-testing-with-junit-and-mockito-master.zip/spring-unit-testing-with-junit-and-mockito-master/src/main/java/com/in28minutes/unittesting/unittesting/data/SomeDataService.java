package com.in28minutes.unittesting.unittesting.data;

public interface SomeDataService {

	int[] retrieveAllData();
	
	//int retrieveSpecificData();

}
