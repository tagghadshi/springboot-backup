package com.example.ribbonserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
