package com.tcs.springbootwebfluxdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebfluxDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebfluxDemoApplication.class, args);
	}

}
