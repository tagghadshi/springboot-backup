package com.tcs.springbootwebfluxdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebfluxDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
